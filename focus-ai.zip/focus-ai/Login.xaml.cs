using System;
using System.Configuration;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace focus_ai
{
    public partial class Login : Window
    {
        private readonly string FirebaseApiKey     = AppSettings.Get("FirebaseApiKey");
        private readonly string GoogleClientId     = AppSettings.Get("GoogleClientId");

        private const string RegPath = @"Software\FocusAI";

        public Login()
        {
            InitializeComponent();
            WindowHelper.MoveToPrimaryMonitor(this);
            ApplySystemTheme();
            LanguageManager.Register(this, LanguageToggleBtn);
            LoadRememberedCredentials();
        }

        private bool IsSystemDarkTheme()
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
                var value = key?.GetValue("AppsUseLightTheme");
                return value is int i && i == 0;
            }
            catch { return false; }
        }

        private void ApplySystemTheme()
        {
            if (IsSystemDarkTheme()) ApplyDark();
            else ApplyLight();
        }

        private void ApplyLight()
        {
            WindowBackground.Color = (Color)FindResource("LightWindowBg");
            SetBrush("CardBgBrush", "LightCardBg");
            SetBrush("TextPrimaryBrush", "LightTextPrimary");
            SetBrush("TextSecBrush", "LightTextSecondary");
            SetBrush("BorderBrush", "LightBorder");
            SetBrush("InputBgBrush", "LightInputBg");
            SetBrush("DividerBrush", "LightDivider");
            CardShadow.Color = Colors.Black;
            CardShadow.Opacity = 0.12;
        }

        private void ApplyDark()
        {
            WindowBackground.Color = (Color)FindResource("DarkWindowBg");
            SetBrush("CardBgBrush", "DarkCardBg");
            SetBrush("TextPrimaryBrush", "DarkTextPrimary");
            SetBrush("TextSecBrush", "DarkTextSecondary");
            SetBrush("BorderBrush", "DarkBorder");
            SetBrush("InputBgBrush", "DarkInputBg");
            SetBrush("DividerBrush", "DarkDivider");
            CardShadow.Color = Colors.Black;
            CardShadow.Opacity = 0.50;
        }

        private void SetBrush(string brushKey, string colorKey)
        {
            Resources[brushKey] = new SolidColorBrush((Color)FindResource(colorKey));
        }

        private void LoadRememberedCredentials()
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(RegPath);
                if (key == null) return;

                bool remember = key.GetValue("RememberMe") as string == "1";
                RememberMeCheckBox.IsChecked = remember;

                if (remember)
                {
                    string email = key.GetValue("Email") as string ?? "";
                    EmailTextBox.Text = email;
                    if (!string.IsNullOrEmpty(email))
                        PasswordBox.Focus();
                }
            }
            catch { }
        }

        private void SaveSession(string email, string idToken, string uid, bool remember)
        {
            try
            {
                using var key = Registry.CurrentUser.CreateSubKey(RegPath);
                key.SetValue("RememberMe", remember ? "1" : "0");
                key.SetValue("Email", email);
                key.SetValue("LoggedIn", "1");
                key.SetValue("IdToken", SessionTokenProtector.Protect(idToken));
                key.SetValue("Uid", uid);
            }
            catch { }
        }

        private void SaveSessionGoogle(string email, string idToken, string uid)
        {
            try
            {
                using var key = Registry.CurrentUser.CreateSubKey(RegPath);
                key.SetValue("RememberMe", "1");
                key.SetValue("Email", email);
                key.SetValue("LoggedIn", "1");
                key.SetValue("IdToken", SessionTokenProtector.Protect(idToken));
                key.SetValue("Uid", uid);
            }
            catch { }
        }

        private bool EnsureFirebaseApiKeyConfigured()
        {
            if (!string.IsNullOrWhiteSpace(FirebaseApiKey))
                return true;

            MessageBox.Show("Configure the FOCUSAI_FIREBASE_API_KEY environment variable and restart Focus AI.",
                "Focus AI configuration", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        private async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text.Trim();
            string password = PasswordBox.Password;

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show(LanguageManager.T("Email and password are required."), LanguageManager.T("Warning"),
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!EnsureFirebaseApiKeyConfigured())
                return;

            SetUiBusy(true);

            try
            {
                using var client = new HttpClient();
                var url = $"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={FirebaseApiKey}";
                var body = new { email, password, returnSecureToken = true };

                var response = await client.PostAsync(url,
                    new StringContent(JsonConvert.SerializeObject(body), Encoding.UTF8, "application/json"));
                var responseJson = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    var parsed = JObject.Parse(responseJson);
                    string token = parsed["idToken"]?.ToString() ?? "";
                    string uid = parsed["localId"]?.ToString() ?? "";
                    bool remember = RememberMeCheckBox.IsChecked == true;

                    SaveSession(email, token, uid, remember);

                    await OpenDashboardOrSetup(token, uid);
                    Close();
                }
                else
                {
                    var error = JObject.Parse(responseJson);
                    var message = error["error"]?["message"]?.ToString();

                    if (message == "EMAIL_NOT_FOUND" || message == "INVALID_PASSWORD" || message == "INVALID_LOGIN_CREDENTIALS")
                        MessageBox.Show(LanguageManager.T("Incorrect email or password."), LanguageManager.T("Sign-in error"),
                                        MessageBoxButton.OK, MessageBoxImage.Error);
                    else if (message == "USER_DISABLED")
                        MessageBox.Show(LanguageManager.T("The account has been disabled."), LanguageManager.T("Sign-in error"),
                                        MessageBoxButton.OK, MessageBoxImage.Error);
                    else
                        MessageBox.Show(message, LanguageManager.T("Sign-in error"),
                                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, LanguageManager.T("Error"), MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally { SetUiBusy(false); }
        }

        private async void GoogleLoginButton_Click(object sender, RoutedEventArgs e)
        {
            if (!EnsureFirebaseApiKeyConfigured())
                return;

            SetUiBusy(true);

            try
            {
                string googleIdToken = await GetGoogleIdTokenAsync();

                using var client = new HttpClient();
                var url = $"https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key={FirebaseApiKey}";
                var body = new
                {
                    postBody = $"id_token={googleIdToken}&providerId=google.com",
                    requestUri = "http://localhost",
                    returnSecureToken = true
                };

                var response = await client.PostAsync(url,
                    new StringContent(JsonConvert.SerializeObject(body), Encoding.UTF8, "application/json"));
                var responseJson = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    var parsed = JObject.Parse(responseJson);
                    string email = parsed["email"]?.ToString() ?? "";
                    string firebaseToken = parsed["idToken"]?.ToString() ?? "";
                    string uid = parsed["localId"]?.ToString() ?? "";

                    SaveSessionGoogle(email, firebaseToken, uid);

                    await OpenDashboardOrSetup(firebaseToken, uid);
                    Close();
                }
                else
                {
                    var error = JObject.Parse(responseJson);
                    MessageBox.Show(error["error"]?["message"]?.ToString() ?? LanguageManager.T("Google sign-in failed."),
                        LanguageManager.T("Error"), MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, LanguageManager.T("Error"), MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally { SetUiBusy(false); }
        }

        private Task<string> GetGoogleIdTokenAsync()
        {
            return GooglePkceAuthenticator.GetIdTokenAsync(GoogleClientId);
        }

        private async void ForgotPasswordLink_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text.Trim();

            if (string.IsNullOrEmpty(email))
            {
                MessageBox.Show(LanguageManager.T("Enter your email address to reset your password."), LanguageManager.T("Password reset"),
                                MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (!EnsureFirebaseApiKeyConfigured())
                return;

            try
            {
                using var client = new HttpClient();
                var url = $"https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key={FirebaseApiKey}";
                var body = new { requestType = "PASSWORD_RESET", email };

                var response = await client.PostAsync(url,
                    new StringContent(JsonConvert.SerializeObject(body), Encoding.UTF8, "application/json"));

                if (response.IsSuccessStatusCode)
                    MessageBox.Show(LanguageManager.T("Password reset email sent. Check your inbox."), LanguageManager.T("Password reset"),
                                    MessageBoxButton.OK, MessageBoxImage.Information);
                else
                    MessageBox.Show(LanguageManager.T("Could not send the reset email. Check the address you entered."), LanguageManager.T("Error"),
                                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, LanguageManager.T("Error"), MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SetUiBusy(bool busy)
        {
            LoginButton.IsEnabled = !busy;
            GoogleSignUpButton.IsEnabled = !busy;
            LoginButton.Content = busy ? LanguageManager.T("Processing...") : LanguageManager.T("Sign in");
        }

        private void SignUpLink_Click(object sender, RoutedEventArgs e)
        {
            new SignUp().Show();
            Close();
        }
        private async Task OpenDashboardOrSetup(string token, string uid)
        {
            bool needsSetup = await CheckNeedsProfileSetup(token, uid);

            if (needsSetup)
            {
                bool isDark = IsSystemDarkTheme();
                var setup = new ProfileEditWindow(isDark, isSetupMode: true);
                setup.Show();
            }
            else
            {
                new Dashboard().Show();
            }
        }

        private async Task<bool> CheckNeedsProfileSetup(string token, string uid)
        {
            try
            {
                string baseUrl = AppSettings.Get("RealtimeDatabaseUrl");
                string url = $"{baseUrl}/doctors/{uid}/setup.json?auth={token}";

                using var client = new HttpClient();
                string response = await client.GetStringAsync(url);

                if (response == "true") return false;

                string legacyUrl = $"{baseUrl}/{uid}/profile/setup.json?auth={token}";
                string legacyResponse = await client.GetStringAsync(legacyUrl);
                return legacyResponse == "null" || legacyResponse == "false" || string.IsNullOrWhiteSpace(legacyResponse);
            }
            catch
            {
                return false;
            }
        }
    }
}
